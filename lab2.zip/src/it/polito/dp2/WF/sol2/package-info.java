@XmlSchema(
    namespace="http://www.w3schools.com", 
    elementFormDefault=XmlNsForm.QUALIFIED)
package it.polito.dp2.WF.sol2;

import javax.xml.bind.annotation.*;